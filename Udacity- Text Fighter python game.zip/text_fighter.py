# Be sure to pip install pyfiglet to run this if you don't already have it!
import pyfiglet
from pyfiglet import Figlet
import time
import random

# Common:
ascii_banner = Figlet(font="standard")


def nice_text_scroller(string, pausetype):
    for char in string:
        print(char, end="")
        time.sleep(.03)
    if pausetype == "pause":
        time.sleep(1)


def ellipse_scroller():
    string = "..."
    for char in string:
        print(char, end="")
        time.sleep(.8)


def standard_banner(banner_text):
    ascii_banner = Figlet(font="standard")
    print(ascii_banner.renderText(banner_text))
    time.sleep(1)


# Intro:


def title_screen():
    ascii_sub_banner = Figlet(font="cursive")
    standard_banner("TEXT FIGHTER")
    print(ascii_sub_banner.renderText("The World Warrior"))
    starting_game()


def starting_game():
    time.sleep(1)
    to_begin = input("Player One input 1 to begin\n")
    if to_begin == "1":
        country_selection()
    else:
        starting_game()


def country_selection():
    time.sleep(1)
    ascii_country = Figlet(font="small")
    print(ascii_country.renderText("Select Your Country"))
    time.sleep(1)
    country_selection_prompt()


def country_selection_prompt():
    select_country = input("Input 1 to select Japan (hard) or 2 for"
                           " U.S.A. (easy)\n")
    if select_country == '1':
        journey("Japan")
    elif select_country == '2':
        journey("USA")
    else:
        country_selection_prompt()


# Story:

def journey(country):
    if country == "Japan":
        jp_p1 = ("\n\nExcited to begin the tournament, Ryu set out on foot"
                 " from his home in Osaka to the temple grounds where the"
                 " match is set.")
        jp_p2 = ("\n\nIt was a crisp Fall morning, and a thin kaleidoscope"
                 " of leaves"
                 " covered the ground beneath Ryu's bare feet, gently"
                 " crunching as he strided"
                 " toward the temple.")
        jp_p3 = ("\n\nUp ahead, the path's ground covering begins to raise"
                 " as the leaves"
                 " pile higher, plateauing in a mound nearly up to"
                 " his knees.")
        jp_p4 = ("\n\nOverhead, the tree branches are getting thicker"
                 " accordingly."
                 " As the leaves get higher, Ryu contemplates his next move")
        nice_text_scroller(jp_p1, "pause")
        nice_text_scroller(jp_p2, "pause")
        nice_text_scroller(jp_p3, "pause")
        nice_text_scroller(jp_p4, "nopause")
        ellipse_scroller()
        leaf_descision()
    if country == "USA":
        usa_p1 = ("\n\nExcited to begin the tournament, boarding pass"
                  " in hand, Ryu waited to enter the boarding area"
                  " for his flight to the United States.")
        usa_p2 = ("\n\nThe airport's customs agent approaches Ryu and"
                  " asks him to remove his shoes")
        usa_p3 = ("\n\nBut then looks down in amazement and realizes"
                  " that he isn't wearing any!")
        usa_p4 = ("\n\nRyu is a serious warrior, all business, and"
                  " since his business is tournament fighting, he saw"
                  " no need to bring shoes.")
        usa_p5 = ("\n\nRyu boards the flight unabated. Nine hours and"
                  " a Julia Roberts"
                  " movie marathon later, he arrives in San Francisco.")
        usa_p6 = ("\n\nHe takes the BART to Oakland, and stepping off"
                  " the train,"
                  " he has at last arrived at his destination.")
        usa_p7 = ("\n\nHe looks around for his opponent, Joe,"
                  " and spots him in the designated fighting zone, behind"
                  " some disused, graffiti-covered train cars.")
        usa_p8 = ("\n\nRyu stretches, twists his neck to one side, and"
                  " cracks his knuckles.")
        usa_p9 = ("\n\nHe approaches Joe."
                  " At last, the fight is about to begin!")
        nice_text_scroller(usa_p1, "pause")
        nice_text_scroller(usa_p2, "nopause")
        ellipse_scroller()
        nice_text_scroller(usa_p3, "pause")
        nice_text_scroller(usa_p4, "pause")
        nice_text_scroller(usa_p5, "pause")
        nice_text_scroller(usa_p6, "pause")
        nice_text_scroller(usa_p7, "pause")
        nice_text_scroller(usa_p8, "pause")
        nice_text_scroller(usa_p9, "pause")
        fight_prompt()
        battle_start("Joe")


def leaf_descision():
    leaf_action = input("\n\nInput 1 to attempt to jump over the leaves,"
                        " or 2 to just wade through them\n")
    if leaf_action == '1':
        nice_text_scroller("\n\nTo be on the safe side, Ryu jumps over"
                           " the deepest part of the leaves."
                           " He nearly hits his head on a low hanging"
                           " branch, but as a skilled warrior he easily"
                           " saw it coming.", "pause")
        nice_text_scroller("\n\nHe ducks out of the way as he jumps,"
                           " clearing the leaves and the branch"
                           " easily.", "pause")
        japan_battle_area_approach()
    elif leaf_action == '2':
        nice_text_scroller("\n\nAs a mighty warrior, Ryu cannot"
                           " be bothered to avoid a mere pile of leaves."
                           " He walks right through them", "nopause")
        ellipse_scroller()
        nice_text_scroller(" And steps right into some"
                           " broken glass!", "pause")
        nice_text_scroller("\n\nHe rips off a piece of his robe"
                           " and wraps his ailing feet,"
                           " but he could feel the glass going under"
                           " the skin, and he knows with every"
                           " step that it's in there.", "pause")
        nice_text_scroller("\n\nHe was hoping to go into battle"
                           " with his full health of 100 hit points,"
                           " but alas, the damage is done.", "pause")
        hit_math("small_hit")
        japan_battle_area_approach()


def japan_battle_area_approach():
    jp_bap_1 = ("\n\nAt last, after several hours journey"
                " on foot, Ryu arrives at the temple,"
                " the site of his battle with his opponent, Retsu.")
    jp_bap_2 = ("\n\nRyu spots Retsu standing out in front of the temple,"
                " as expected.")
    jp_bap_3 = ("\n\nTheir eyes meet. Retsu twists his neck to one side,"
                " and cracks his knuckles.")
    jp_bap_4 = ("\n\nRyu knows he is in for a difficult battle,"
                " but it's time to do what he came here to do."
                " The battle is about to begin")
    nice_text_scroller(jp_bap_1, "pause")
    nice_text_scroller(jp_bap_2, "pause")
    nice_text_scroller(jp_bap_3, "pause")
    nice_text_scroller(jp_bap_4, "nopause")
    ellipse_scroller()
    print("\n\n")
    fight_prompt()
    battle_start("Retsu")

# Battle:


ryu_hitslist = []
retsu_hitslist = []
joe_hitslist = []
hits = ["small_hit", "medium_hit", "heavy_hit"]


def fight_prompt():
    time.sleep(1)
    print(ascii_banner.renderText("\nFIGHT!"))
    time.sleep(1)


def battle_start(opponent):
    if opponent == "Retsu":
        nice_text_scroller("\n"+opponent + " approaches.", "pause")
        the_battle_hard()
    if opponent == "Joe":
        nice_text_scroller("\n"+opponent + " approaches.", "pause")
        the_battle_easy()


def the_battle_easy():
    who_hits_first = ["ryu_first", "joe_first"]
    battle_input = input("\n\nInput your command,"
                         " or input 1 for a list of attacks.\n")
    if battle_input == '1':
        moves_list_easy()
        the_battle_easy()
    elif battle_input.lower() == 'la':
        small_attack_usa_order(random.choice(who_hits_first))
        the_battle_easy()
    elif battle_input.lower() == 'ma':
        med_attack_usa_order(random.choice(who_hits_first))
        the_battle_easy()
    elif battle_input.lower() == 'ha':
        hev_attack_usa_order(random.choice(who_hits_first))
        the_battle_easy()
    elif battle_input.lower() == 'hadoken':
        sp_attack_usa_order(random.choice(who_hits_first))
        the_battle_easy()
    else:
        the_battle_easy()


def the_battle_hard():
    who_hits_first = ["ryu_first", "retsu_first"]
    battle_input = input("\n\nInput your command,"
                         " or input 1 for a list of attacks.\n")
    if battle_input == '1':
        moves_list_hard()
    elif battle_input.lower() == 'la':
        small_attack_jp_order(random.choice(who_hits_first))
        the_battle_hard()
    elif battle_input.lower() == 'ma':
        med_attack_jp_order(random.choice(who_hits_first))
        the_battle_hard()
    elif battle_input.lower() == 'ha':
        hev_attack_jp_order(random.choice(who_hits_first))
        the_battle_hard()
    elif battle_input.lower() == 'hadoken':
        sp_attack_jp_order(random.choice(who_hits_first))
        the_battle_hard()
    else:
        the_battle_hard()


def moves_list_easy():
    print("\n\n******MOVES: INPUT THE SHORTCUT TO USE THE MOVE******"
          "\nNote that different attacks tend to do better"
          " against different opponents."
          "\nBeware, if you escalate the fight, your opponent"
          " may do the same."
          "\n\nLight Attack- LA"
          "\nMedium Attack- MA"
          "\nHeavy Attack- HA"
          "\nFireball Attack- HADOKEN"
          )
    the_battle_easy()


def moves_list_hard():
    print("\n\n******MOVES: INPUT THE SHORTCUT TO USE THE MOVE******"
          "\nNote that different attacks tend to do better"
          " against different opponents."
          "\nBeware, if you escalate the fight, your opponent"
          " may do the same."
          "\n\nLight Attack- LA"
          "\nMedium Attack- MA"
          "\nHeavy Attack- HA"
          "\n???????- ??"
          )
    the_battle_hard()


def calculate_hitslist(fighter):
    defeat_text = " has been defeated!\n\n"
    rem_hp = " hit points remaining.\n"
    if fighter == "Ryu":
        if 100 - sum(ryu_hitslist) <= 0:
            nice_text_scroller(fighter + defeat_text, "pause")
            you_lose()
        else:
            nice_text_scroller(str(100 - sum(ryu_hitslist)) + rem_hp, "pause")
    elif fighter == "Retsu":
        if 100 - sum(retsu_hitslist) <= 0:
            nice_text_scroller(fighter + defeat_text, "pause")
            ryu_wins("Japan")
        else:
            nice_text_scroller(str(100 - sum(retsu_hitslist))
                               + rem_hp, "pause")
    elif fighter == "Joe":
        if 100 - sum(joe_hitslist) <= 0:
            nice_text_scroller(fighter + defeat_text, "pause")
            ryu_wins("USA")
        else:
            nice_text_scroller(str(100 - sum(joe_hitslist)) + rem_hp, "pause")


def hit_math(hittype):
    if hittype == "small_hit":
        n = random.randint(1, 10)
        ryu_hitslist.append(n)
        nice_text_scroller("\n\nRyu has taken " + str(n) +
                           " damage. ", "pause")
        calculate_hitslist("Ryu")
    elif hittype == "small_hit_retsu":
        n = random.randint(1, 9)
        retsu_hitslist.append(n)
        nice_text_scroller("\n\nRetsu has"
                           " taken " + str(n) + " damage. ", "pause")
        calculate_hitslist("Retsu")
    elif hittype == "small_hit_joe":
        n = random.randint(1, 11)
        joe_hitslist.append(n)
        nice_text_scroller("\n\nJoe has taken " + str(n) +
                           " damage. ", "pause")
        calculate_hitslist("Joe")
    elif hittype == "medium_hit":
        n = random.randint(11, 20)
        ryu_hitslist.append(n)
        nice_text_scroller("\n\nRyu has taken " + str(n) +
                           " damage. ", "pause")
        calculate_hitslist("Ryu")
    elif hittype == "medium_hit_joe":
        n = random.randint(1, 19)
        joe_hitslist.append(n)
        nice_text_scroller("\n\nJoe has taken " + str(n) +
                           " damage. ", "pause")
        calculate_hitslist("Joe")
    elif hittype == "medium_hit_retsu":
        n = random.randint(11, 15)
        retsu_hitslist.append(n)
        nice_text_scroller("\n\nRetsu has"
                           " taken " + str(n) + " damage. ", "pause")
        calculate_hitslist("Retsu")
    elif hittype == "heavy_hit":
        n = random.randint(21, 60)
        ryu_hitslist.append(n)
        nice_text_scroller("\n\nRyu has taken " + str(n) +
                           " damage. ", "pause")
        calculate_hitslist("Ryu")
    elif hittype == "heavy_hit_retsu":
        n = random.randint(21, 35)
        retsu_hitslist.append(n)
        nice_text_scroller("\n\nRetsu has"
                           " taken " + str(n) + " damage. ", "pause")
        calculate_hitslist("Retsu")
    elif hittype == "heavy_hit_joe":
        n = random.randint(21, 41)
        joe_hitslist.append(n)
        nice_text_scroller("\n\nJoe has taken " + str(n) +
                           " damage. ", "pause")
        calculate_hitslist("Joe")
    elif hittype == "special_hit_retsu":
        n = random.randint(1, 100)
        retsu_hitslist.append(n)
        nice_text_scroller("\n\nRetsu has taken " + str(n) + " damage. ",
                           "pause")
        calculate_hitslist("Retsu")
    elif hittype == "special_hit_joe":
        n = random.randint(1, 100)
        joe_hitslist.append(n)
        nice_text_scroller("\n\nJoe has taken " + str(n) + " damage. ",
                           "pause")
        calculate_hitslist("Joe")


def small_attack_jp_order(order_value):
    if order_value == "ryu_first":
        nice_text_scroller("\nRyu goes in for a quick, light attack.", "pause")
        hit_math("small_hit_retsu")
        nice_text_scroller("\nHis opponent"
                           " counters with a quick attack.", "pause")
        hit_math("small_hit")
    elif order_value == "retsu_first":
        nice_text_scroller("\nRetsu sneaks in a quick attack.", "pause")
        hit_math("small_hit")
        nice_text_scroller("\nRyu responds"
                           " quickly with a light attack.", "pause")
        hit_math("small_hit_retsu")


def small_attack_usa_order(order_value):
    if order_value == "ryu_first":
        nice_text_scroller("\nRyu goes in for a quick, light attack.", "pause")
        hit_math("small_hit_joe")
        nice_text_scroller("\nJoe delivers a quick counterpunch.", "pause")
        hit_math("small_hit")
    elif order_value == "joe_first":
        nice_text_scroller("\nJoe delivers a quick but powerful jab.",
                           "pause")
        hit_math("small_hit")
        nice_text_scroller("\nRyu goes in for a quick, light attack.",
                           "pause")
        hit_math("small_hit_joe")


def med_attack_usa_order(order_value):
    if order_value == "ryu_first":
        nice_text_scroller("\nRyu goes in for a medium leg sweep.", "pause")
        hit_math("medium_hit_joe")
        nice_text_scroller("\nJoe counters with a stomp.", "pause")
        hit_math("medium_hit")
    elif order_value == "joe_first":
        nice_text_scroller("\nJoe's leaden knee connects with Ryu's abdomen."
                           " The wind goes rushing out of Ryu's lungs.",
                           "pause")
        hit_math("medium_hit")
        nice_text_scroller("\nRyu goes in for a medium"
                           " attack, and lands a decent blow.", "pause")
        hit_math("medium_hit_joe")


def hev_attack_usa_order(order_value):
    if order_value == "ryu_first":
        nice_text_scroller("\nRyu goes in for a heavy attack,"
                           " dealing massive damage.", "pause")
        hit_math("heavy_hit_joe")
        nice_text_scroller("\nOof! His opponent counters with"
                           " a heavy attack of his own."
                           " That is going to leave a mark.", "pause")
        hit_math("heavy_hit")
    elif order_value == "joe_first":
        nice_text_scroller("\nOof! Joe delivers a piston punch"
                           " at full power, straight into Ryu's face.",
                           "pause")
        hit_math("heavy_hit")
        nice_text_scroller("\nRyu goes in for a heavy attack,"
                           " giving all he's got.", "pause")
        hit_math("heavy_hit_joe")


def sp_attack_usa_order(order_value):
    if order_value == "ryu_first":
        nice_text_scroller("\nRyu throws a fireball- Hadoken!", "pause")
        hit_math("special_hit_joe")
        nice_text_scroller("\nHis opponent thrashes wildly in"
                           " his direction!", "pause")
        hit_math(random.choice(hits))
    elif order_value == "joe_first":
        nice_text_scroller("\nJoe thrashes wildly in Ryu's direction!",
                           "pause")
        hit_math(random.choice(hits))
        nice_text_scroller("\nRyu throws a fireball!", "pause")
        hit_math("special_hit_joe")


def med_attack_jp_order(order_value):
    if order_value == "ryu_first":
        nice_text_scroller("\nRyu goes in for a medium attack, and lands a"
                           " decent blow.", "pause")
        hit_math("medium_hit_retsu")
        nice_text_scroller("\nHis opponent counters with a mid-sized"
                           " attack of his own.", "pause")
        hit_math("medium_hit")
    elif order_value == "retsu_first":
        nice_text_scroller("\nRetsu leaps in a mid-sized kick to"
                           " Ryu's jaw.", "pause")
        hit_math("medium_hit")
        nice_text_scroller("\nRyu goes in for a medium attack, and lands"
                           " a decent blow.", "pause")
        hit_math("medium_hit_retsu")


def hev_attack_jp_order(order_value):
    if order_value == "ryu_first":
        nice_text_scroller("\nRyu goes in for a heavy attack, dealing"
                           " massive damage.", "pause")
        hit_math("heavy_hit_retsu")
        nice_text_scroller("\nOof! His opponent counters with a heavy"
                           " attack of his own."
                           " That is going to leave a mark.", "pause")
        hit_math("heavy_hit")
    elif order_value == "retsu_first":
        nice_text_scroller("\nOof! Retsu delivers a heavy roundhouse kick"
                           " to Ryu.", "pause")
        hit_math("heavy_hit")
        nice_text_scroller("\nRyu goes in for a heavy attack, dealing massive"
                           " damage.", "pause")
        hit_math("heavy_hit_retsu")


def sp_attack_jp_order(order_value):
    if order_value == "ryu_first":
        nice_text_scroller("\nRyu throws a fireball!", "pause")
        hit_math("special_hit_retsu")
        nice_text_scroller("\nHis opponent thrashes wildly"
                           " in his direction!", "pause")
        hit_math(random.choice(hits))
    elif order_value == "retsu_first":
        nice_text_scroller("\nRetsu thrashes wildly"
                           " in Ryu's direction!", "pause")
        hit_math(random.choice(hits))
        nice_text_scroller("\nRyu throws a fireball!", "pause")
        hit_math("special_hit_retsu")


def you_lose():
    nice_text_scroller("Ryu has lost the battle!\n\n", "pause")
    nice_text_scroller("His opponent stands over his battered body, chuckles,"
                       " and says:\n\n", "pause")
    nice_text_scroller("'You've got a lot to learn before you beat me."
                       " Try again kiddo!"
                       " ah ha ha!'\n\n", "pause")
    game_over()


def game_over():
    standard_banner("GAME OVER")
    do_over_prompt()


def do_over_prompt():
    do_over = input("Input 1 to start over, or 2 to exit the game.\n")
    if do_over == '1':
        ryu_hitslist.clear()
        retsu_hitslist.clear()
        joe_hitslist.clear()
        title_screen()
    elif do_over == '2':
        nice_text_scroller("Thanks for playing.", "pause")
        exit()
    else:
        do_over_prompt()


def ryu_wins(country):
    standard_banner("RYU WINS!")
    if country == "Japan":
        nice_text_scroller("Ryu helps Retsu back to his feet,"
                           " accepts high fives from the small crowd"
                           " of onlookers, and collects the prize", "nopause")
        ellipse_scroller()
        nice_text_scroller("$5000!\n", "pause")
        nice_text_scroller("\nAs he gazes off into the sunset, he"
                           " contemplates his next battle.\n\nTime to start"
                           " training!\n\n", "pause")
        do_over_prompt()
    elif country == "USA":
        nice_text_scroller("Ryu helps Joe back to his feet,"
                           " although he is clearly struggling to stand."
                           " The handful of onlookers were clearly with Joe"
                           " and are looking menacingly at Ryu."
                           " He quickly collects the"
                           " $5000 reward and gets back on the BART before"
                           " the crowd turns into a mob.", "pause")
        nice_text_scroller("\n\nAs he gazes off into the sunset from"
                           " his train window, he contemplates"
                           " his next battle. The next one might not"
                           " be so easy.\n", "pause")
        do_over_prompt()


# Launch:
title_screen()
