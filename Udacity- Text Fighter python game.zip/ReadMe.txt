You must install pyfiglet to run this game:

pip install pyfiglet==0.7

More info: https://pypi.org/project/pyfiglet/0.7/